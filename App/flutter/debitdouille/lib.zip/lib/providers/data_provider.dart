import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import '../models/capteur_data.dart';
import '../services/ble_service.dart';
import '../services/simulation_service.dart';
import '../utils/constants.dart';

class DataProvider with ChangeNotifier {
  final BleService ble;
  final SimulationService sim;

  CapteurData data = CapteurData.zero();
  String? lastJson;                   // trame brute la plus récente
  DateTime? lastTick;                 // dernière réception
  bool get isAlive => lastTick != null && DateTime.now().difference(lastTick!) <= tickDuration;

  BluetoothDevice? get connectedDevice => _connectedDevice;
  BluetoothDevice? _connectedDevice;

  StreamSubscription<String>? _bleSub;

  DataProvider({required this.ble, required this.sim});

  Future<List<BluetoothDevice>> scan() => ble.scanDevices();

  Future<void> connect(BluetoothDevice d) async {
    await ble.connectTo(d);
    _connectedDevice = d;
    _bleSub?.cancel();
    _bleSub = ble.jsonStream.listen(_onJson);
    notifyListeners();
  }

  Future<void> disconnect() async {
    await ble.disconnect();
    _connectedDevice = null;
    await _bleSub?.cancel();
    _bleSub = null;
    notifyListeners();
  }

void _onJson(String s) {
  print("📩 Trame reçue BLE : $s"); // 👈 AJOUT
  lastJson = s;
  try {
    final Map<String, dynamic> j = jsonDecode(s);
    print("✅ JSON décodé avec succès : $j"); // 👈 AJOUT
    data = CapteurData.fromJson(j);
    lastTick = DateTime.now();
    notifyListeners();
  } catch (e) {
    print("⛔ Erreur JSON : $e"); // 👈 AJOUT
    lastTick = DateTime.now();
    notifyListeners();
  }
}



  // Simulation ponctuelle (bouton)
  void pushSimulatedFrame(int pairs) {
    final s = sim.generateJson(pairs: pairs);
    _onJson(s);
  }

  // Calibration – proxies
  Future<void> requestCoefficients() => ble.requestCoefficients();
  Future<void> sendUpdatedCoefficients(Map<String, Map<String, double>> coeff) =>
      ble.sendUpdatedCoefficients(coeff);
}
