import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AppPage { home, bluetooth, calibration, settings }

class SettingsProvider with ChangeNotifier {
  int pairs = 1;              // 1..4
  bool showDebug = false;     // afficher trame JSON en bas
  bool showSimButton = false; // afficher bouton simulation
  AppPage page = AppPage.home;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    pairs = p.getInt("pairs") ?? 1;
    showDebug = p.getBool("debug") ?? false;
    showSimButton = p.getBool("simButton") ?? false;
    notifyListeners();
  }

  Future<void> setPairs(int v) async {
    pairs = v.clamp(1,4);
    final p = await SharedPreferences.getInstance();
    await p.setInt("pairs", pairs);
    notifyListeners();
  }

  Future<void> setShowDebug(bool v) async {
    showDebug = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool("debug", v);
    notifyListeners();
  }

  Future<void> setShowSimButton(bool v) async {
    showSimButton = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool("simButton", v);
    notifyListeners();
  }

  void go(AppPage p) { page = p; notifyListeners(); }
}
