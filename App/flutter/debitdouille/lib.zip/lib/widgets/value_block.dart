import 'package:flutter/material.dart';
import '../utils/constants.dart';

class ValueBlock extends StatelessWidget {
  final String label;
  final String value;
  final String unit;
  final double fontScale;

  const ValueBlock({
    super.key,
    required this.label,
    required this.value,
    required this.unit,
    this.fontScale = 1.0,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(label, style: const TextStyle(color: AppColors.dim, fontSize: 16)),
        const SizedBox(height: 6),
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(value, style: TextStyle(color: AppColors.text, fontSize: 48 * fontScale, fontWeight: FontWeight.bold)),
            const SizedBox(width: 6),
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: Text(unit, style: const TextStyle(color: AppColors.dim, fontSize: 16)),
            ),
          ],
        ),
      ],
    );
  }
}
