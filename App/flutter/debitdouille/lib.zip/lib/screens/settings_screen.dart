import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/settings_provider.dart';
import '../utils/constants.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsProvider>();
    return Container(
      color: AppColors.background,
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          const Text("Paramètres d'affichage", style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    const Text("Paires de débits :", style: TextStyle(color: Colors.white)),
    const SizedBox(height: 8),
    Row(
      children: List.generate(4, (i) {
        final value = i + 1;
        final isSelected = s.pairs == value;
        return Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              backgroundColor: isSelected ? Colors.white : Colors.transparent,
              side: BorderSide(color: Colors.white),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            onPressed: () => s.setPairs(value),
            child: Text(
              value.toString(),
              style: TextStyle(
                color: isSelected ? Colors.black : Colors.white,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        );
      }),
    ),
  ],
),

          SwitchListTile(
            value: s.showDebug,
            onChanged: s.setShowDebug,
            title: const Text("Afficher trame JSON (debug)", style: TextStyle(color: Colors.white)),
            activeColor: Colors.white,
          ),
          SwitchListTile(
            value: s.showSimButton,
            onChanged: s.setShowSimButton,
            title: const Text("Afficher bouton Simulation", style: TextStyle(color: Colors.white)),
            activeColor: Colors.white,
          ),
        ],
      ),
    );
  }
}
