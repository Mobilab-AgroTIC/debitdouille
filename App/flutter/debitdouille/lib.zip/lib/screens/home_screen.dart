import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/settings_provider.dart';
import '../providers/data_provider.dart';
import '../utils/constants.dart';
import '../widgets/value_block.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final dp = context.watch<DataProvider>();
    final d = dp.data;

    // Grille : pression (haut), débits (milieu), vitesse (bas)
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      child: Column(
        children: [
          // Pression
          Center(
            child: ValueBlock(
              label: "Pression",
              value: d.P.toStringAsFixed(2),
              unit: "bar",
              fontScale: 1.3,
            ),
          ),
          const SizedBox(height: 16),

          // Débits : gauche (gauche), droite (droite)
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: _debitsColumn("DG", d.DG, settings.pairs),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _debitsColumn("DD", d.DD, settings.pairs),
                ),
              ],
            ),
          ),

          // Vitesse
          const SizedBox(height: 6),
          Center(
            child: ValueBlock(
              label: "Vitesse",
              value: d.V.toStringAsFixed(2),
              unit: "km/h",
              fontScale: 1.1,
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  Widget _debitsColumn(String prefix, List<double> values, int pairs) {
    final items = List.generate(pairs, (i) {
      final v = values[i];
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: ValueBlock(
          label: "$prefix${i+1}",
          value: v.toStringAsFixed(2),
          unit: "L/min",
        ),
      );
    });
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: items,
    );
  }
}
